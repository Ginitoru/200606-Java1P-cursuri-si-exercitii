package Synchronization.Semaphore;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExempluSemaphore {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Runnable task = new SemaphoreRunnable();

        executorService.execute(task);
        executorService.execute(task);
        executorService.execute(task);

        executorService.shutdown();
    }
}
