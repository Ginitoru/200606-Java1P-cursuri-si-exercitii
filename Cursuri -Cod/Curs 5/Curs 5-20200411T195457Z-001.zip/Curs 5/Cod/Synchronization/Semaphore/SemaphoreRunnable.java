package Synchronization.Semaphore;

import java.util.concurrent.Semaphore;

public class SemaphoreRunnable implements Runnable {

    private int x;
    private Semaphore semaphore = new Semaphore(1);

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            try {
                semaphore.acquire();
                //ce se intampla daca avem aici o exceptie ?
                x++;
                System.out.println(x);

                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            semaphore.release();
        }
    }
}
