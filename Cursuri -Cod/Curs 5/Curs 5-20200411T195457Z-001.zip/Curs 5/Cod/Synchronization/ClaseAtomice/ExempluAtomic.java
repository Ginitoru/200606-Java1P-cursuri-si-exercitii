package Synchronization.ClaseAtomice;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExempluAtomic {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Runnable task = new AtomicRunnable();

        executorService.execute(task);
        executorService.execute(task);
        executorService.execute(task);

        executorService.shutdown();
    }
}
