package Synchronization.ClaseAtomice;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicRunnable implements Runnable {

    private AtomicInteger x = new AtomicInteger(0);

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            try {
                System.out.println(x.incrementAndGet());
                //addAngGet(int delta)
                //decrementAndGet()
                //getAndAdd(int delta)
                //getAndDecrement()
                //getAndIncrement()
                //getAndSet(int newValue)
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
