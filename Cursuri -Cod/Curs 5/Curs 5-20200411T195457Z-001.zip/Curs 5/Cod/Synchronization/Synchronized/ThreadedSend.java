package Synchronization.Synchronized;

public class ThreadedSend extends Thread {

    private String message;
    private Sender sender;

    public ThreadedSend(String message, Sender sender) {
        this.message = message;
        this.sender = sender;
    }

    @Override
    public void run() {
        synchronized (sender) {
            sender.send(message);
        }
    }

//    @Override
//    public void run() {
//        sender.send(message);
//
//    }
}
