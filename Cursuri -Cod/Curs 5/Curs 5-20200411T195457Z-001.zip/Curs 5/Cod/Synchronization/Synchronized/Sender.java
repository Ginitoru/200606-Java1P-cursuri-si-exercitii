package Synchronization.Synchronized;

public class Sender {
    public void send(String message) {
        System.out.println("Sending " + message);
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Thread  interrupted.");
        }
        System.out.println(message + " sent!");
    }

//    public synchronized void send(String message) {
//        System.out.println("Sending " + message);
//        try {
//            Thread.sleep(1000);
//        } catch (Exception e) {
//            System.out.println("Thread  interrupted.");
//        }
//        System.out.println(message + " sent!");
//    }

//    public void send(String message) {
//        synchronized (this) {
//            System.out.println("Sending " + message);
//            try {
//                Thread.sleep(1000);
//            } catch (Exception e) {
//                System.out.println("Thread  interrupted.");
//            }
//            System.out.println(message + " sent!");
//        }
//    }
}
