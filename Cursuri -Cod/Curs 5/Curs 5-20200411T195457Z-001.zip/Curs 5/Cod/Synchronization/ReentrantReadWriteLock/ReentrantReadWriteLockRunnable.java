package Synchronization.ReentrantReadWriteLock;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ReentrantReadWriteLockRunnable implements Runnable {

    private int x;
    private ReentrantReadWriteLock reentrantReadWriteLock
            = new ReentrantReadWriteLock();

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            try {
                read();
                write();
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void write() {
        reentrantReadWriteLock.writeLock().lock();
        System.out.println("Scrie " + getThread());
        x++;
        System.out.println(getThread() + " a terminat de scris!");
        reentrantReadWriteLock.writeLock().unlock();
    }

    private void read() {
        reentrantReadWriteLock.readLock().lock();
        System.out.println("Citeste " + getThread());
        System.out.println(x);
        System.out.println(getThread() + " a terminat de citit!");
        reentrantReadWriteLock.readLock().unlock();
    }

    private String getThread() {
        return Thread.currentThread().getName();
    }
}
