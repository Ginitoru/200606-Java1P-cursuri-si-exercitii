package Synchronization.ReentrantReadWriteLock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExempluReentrantReadWriteLock {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Runnable task = new ReentrantReadWriteLockRunnable();

        executorService.execute(task);
        executorService.execute(task);
        executorService.execute(task);

        executorService.shutdown();
    }
}
