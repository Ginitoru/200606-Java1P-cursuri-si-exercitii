package Synchronization.CyclicBarrier;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExempluCyclicBarrier {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        Runnable task = new CyclicBarrierRunnable();

        executorService.execute(task);
        executorService.execute(task);
        executorService.execute(task);

        executorService.shutdown();
    }
}
