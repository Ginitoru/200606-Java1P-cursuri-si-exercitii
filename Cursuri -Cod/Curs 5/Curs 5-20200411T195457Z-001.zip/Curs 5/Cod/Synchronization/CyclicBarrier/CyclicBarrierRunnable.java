package Synchronization.CyclicBarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierRunnable implements Runnable {

    //exemplu Galeata - Aqua Park
    CyclicBarrier cyclicBarrier = new CyclicBarrier(2);

    @Override
    public void run() {
        String threadName = Thread.currentThread().getName();

        System.out.println(threadName + " a ajuns la bariera..");
        try {
            cyclicBarrier.await();
        } catch (InterruptedException | BrokenBarrierException e) {
            e.printStackTrace();
        }

        System.out.println(threadName + " a trecut de bariera..");
    }
}
