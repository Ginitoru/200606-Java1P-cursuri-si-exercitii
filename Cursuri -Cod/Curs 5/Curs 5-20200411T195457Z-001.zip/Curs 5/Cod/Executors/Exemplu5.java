package Executors;

import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Exemplu5 {


    public static void main(String[] args) {

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();

        try {
            Task2 task = new Task2();

            System.out.println(Instant.now());
            service.schedule(task, 1, TimeUnit.SECONDS);
        } finally {
            service.shutdown();
        }
    }
}



