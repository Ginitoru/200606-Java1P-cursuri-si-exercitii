package Executors;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Exemplu6 {


    public static void main(String[] args) {

        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();

        Task2 task = new Task2();

        service.scheduleAtFixedRate(task, 0, 3, TimeUnit.SECONDS);
        //service.scheduleWithFixedDelay(task, 0, 3, TimeUnit.SECONDS);

    }
}



