package Executors;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplu1 {


    public static void main(String[] args) {
        ExecutorService service = Executors.newSingleThreadExecutor();

        Runnable t = () -> System.out.println("Hello world!");

        service.execute(t);

        service.shutdown();
        //sunt inchise Thread-urile din THread Pool-ul Exercutorului
        //dupa ce au fost executate Taskurile submise pana la shutdown

        service.shutdownNow();
        //se inchide instant Executorul, fara a  mai fi executate Taskurile submise
        //sunt returnate task-urile care erau in executie
    }
}



