package Executors;

import java.util.concurrent.*;

public class ExempluDownload {


    public static void main(String[] args) {
        ExecutorService service = Executors.newSingleThreadExecutor();

        try {
            String url = "http://profs.info.uaic.ro/~acf/java/Cristian_Frasinaru-Curs_practic_de_Java.pdf";
            Callable<String> task = new DownloadRunnable(url);

            System.out.println("Incep descarcarea...");

            //obiectul prin care putem urmari executia Taskului
            Future<String> future = service.submit(task);

            System.out.println("Se descarca...");

            //opreste executia pana cand task-ul pe care il urmareste Future-ul se termina
            //similar cu join pt Thread

            //se blocheaza firul curent pana la terminarea executiei taskului
            try {
                String downloadLocation = future.get();
                System.out.println("Fisier a fost descarcat la " + downloadLocation);
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }

            System.out.println("Exiting...");
        } finally {
            service.shutdown();
        }
    }
}



