package Executors;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplu4 {


    public static void main(String[] args) {
        ExecutorService service = Executors.newCachedThreadPool();

        try {
            Task1 task1 = new Task1();

            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
        } finally {
            service.shutdown();
        }
    }
}



