package Executors;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplu2 {


    public static void main(String[] args) {
        ExecutorService service = Executors.newSingleThreadExecutor();

        try {
            Runnable t = () -> System.out.println("Hello world!");
            Task1 task1 = new Task1();

            service.execute(t);
            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
            service.execute(task1);
        } finally {
            service.shutdown();
        }
    }
}



