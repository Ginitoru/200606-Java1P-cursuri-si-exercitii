package ForkJoinFramework;

import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;

public class ExempluForkJoin {

    public static void main(String[] args) {
        ForkJoinPool forkJoinPool = new ForkJoinPool();
        ForkJoinTask<Integer> task = new MaxTask(Arrays.asList(3, 5, 1, 7, 10, 9, 3));

        int max = forkJoinPool.invoke(task);
        System.out.println(max);
    }
}
